package MyGame;

public class Tile {
        String type; // "town", "monster", "empty"
    public Tile(String t){
        type = t;
    }
    }
