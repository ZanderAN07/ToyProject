package MyGame;

import java.util.Scanner;

public class AdventureGame {

    public static void startGame() {
        Scanner scanner = new Scanner(System.in);
        Player player = new Player();
        GameMap map = new GameMap(5);
        System.out.println("   ▄██████▄     ▄████████   ▄▄▄▄███▄▄▄▄      ▄████████         ▄████████     ███        ▄████████    ▄████████     ███     \n" +
                "  ███    ███   ███    ███ ▄██▀▀▀███▀▀▀██▄   ███    ███        ███    ███ ▀█████████▄   ███    ███   ███    ███ ▀█████████▄ \n" +
                "  ███    █▀    ███    ███ ███   ███   ███   ███    █▀         ███    █▀     ▀███▀▀██   ███    ███   ███    ███    ▀███▀▀██ \n" +
                " ▄███          ███    ███ ███   ███   ███  ▄███▄▄▄            ███            ███   ▀   ███    ███  ▄███▄▄▄▄██▀     ███   ▀ \n" +
                "▀▀███ ████▄  ▀███████████ ███   ███   ███ ▀▀███▀▀▀          ▀███████████     ███     ▀███████████ ▀▀███▀▀▀▀▀       ███     \n" +
                "  ███    ███   ███    ███ ███   ███   ███   ███    █▄                ███     ███       ███    ███ ▀███████████     ███     \n" +
                "  ███    ███   ███    ███ ███   ███   ███   ███    ███         ▄█    ███     ███       ███    ███   ███    ███     ███     \n" +
                "  ████████▀    ███    █▀   ▀█   ███   █▀    ██████████       ▄████████▀     ▄████▀     ███    █▀    ███    ███    ▄████▀   \n" +
                "                                                                                                    ███    ███             ");
        while (player.hp > 0 && map.MonsterCount > 0) {
            map.printMap();
            System.out.println("WASD to move:");
            char move = scanner.nextLine().toLowerCase().charAt(0);
            map.movePlayer(player, move);
        }

        if (player.hp <= 0) {
            System.out.println("  ▄▀  ██   █▀▄▀█ ▄███▄       ████▄     ▄   ▄███▄   █▄▄▄▄ \n" +
                    "▄▀    █ █  █ █ █ █▀   ▀      █   █      █  █▀   ▀  █  ▄▀ \n" +
                    "█ ▀▄  █▄▄█ █ ▄ █ ██▄▄        █   █ █     █ ██▄▄    █▀▀▌  \n" +
                    "█   █ █  █ █   █ █▄   ▄▀     ▀████  █    █ █▄   ▄▀ █  █  \n" +
                    " ███     █    █  ▀███▀               █  █  ▀███▀     █   \n" +
                    "        █    ▀                        █▐            ▀    \n" +
                    "       ▀                              ▐                  \n);");
        } else {
            System.out.println("🎉 All monsters defeated! You win!");
        }
    }

    public static void main(String[] args) {
        startGame();
    }


}
